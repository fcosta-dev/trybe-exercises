module.exports = {
  verbose: true,
  testTimeout: 1000000,
};
