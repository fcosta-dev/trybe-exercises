const challengeResult4 = [{ 'COUNT(product_name)': 45 }];

module.exports = challengeResult4;
