const challengeResult12 = [
  { submitted_date: '2006-04-26T18:26:37.000Z' },
  { submitted_date: '2006-04-26T18:33:28.000Z' },
  { submitted_date: '2006-04-26T18:33:52.000Z' }
];

module.exports = challengeResult12;
