const challengeResult16 = [
{ submitted_date: '2006-03-24T00:00:00.000Z' },
{ submitted_date: '2006-03-24T00:00:00.000Z' },
{ submitted_date: '2006-03-24T00:00:00.000Z' },
{ submitted_date: '2006-03-24T00:00:00.000Z' },
{ submitted_date: '2006-03-24T00:00:00.000Z' },
{ submitted_date: '2006-03-24T00:00:00.000Z' },
{ submitted_date: '2006-03-24T00:00:00.000Z' },
{ submitted_date: '2006-03-24T00:00:00.000Z' },
{ submitted_date: '2006-03-24T00:00:00.000Z' },
{ submitted_date: '2006-03-31T00:00:00.000Z' }
];

module.exports = challengeResult16;
