const challengeResult7 = [{ id: 99 }, { id: 98 }, { id: 97 }, { id: 96 }, { id: 95 }];

module.exports = challengeResult7;
